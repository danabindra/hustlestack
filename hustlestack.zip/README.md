# HustleForge Stack

Self-contained starter for Azure AKS, CI/CD, and observability.